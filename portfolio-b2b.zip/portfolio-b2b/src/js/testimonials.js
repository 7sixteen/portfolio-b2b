/* ===================================================
TESTIMONIALS - API FETCH & CENTERED CAROUSEL
=================================================== */
const avatarImages = [
  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80',
];
/**
* Função principal que será chamada pelo script.js
*/
export async function initTestimonials() {
const cardsContainer = document.getElementById('testimonials-cards');
const prevBtn = document.getElementById('prev-btn');
const nextBtn = document.getElementById('next-btn');
// Trava de segurança: se o container não existir na página, para por aqui
if (!cardsContainer) return;
// 1. Busca os dados na API e renderiza
await loadTestimonials(cardsContainer);
// 2. Configura os eventos dos botões de navegação
if (nextBtn) {
nextBtn.addEventListener('click', () => {
cardsContainer.scrollBy({ left: 340, behavior: 'smooth' });
});
}
if (prevBtn) {
prevBtn.addEventListener('click', () => {
cardsContainer.scrollBy({ left: -340, behavior: 'smooth' });
});

}
}
async function loadTestimonials(cardsContainer) {
  try {
    const response = await fetch('https://jsonplaceholder.typicode.com/users');

    if (!response.ok) {
      throw new Error('Erro ao carregar os dados');
    }

    const users = await response.json();
    const firstFiveUsers = users.slice(0, 5);

    cardsContainer.innerHTML = firstFiveUsers
      .map((user, index) => createCardHTML(user, index))
      .join('');

    initCarouselFocus(cardsContainer);
  } catch (error) {
    console.error('Erro na seção de depoimentos:', error);
  }
}
function createCardHTML(user, index) {
  const avatarUrl =
    avatarImages[index] ||
    `https://ui-avatars.com/api/?name=${encodeURIComponent(user.name)}`;

  const city = user.address?.city ?? 'Brasil';

  // Depoimentos locais em português (a API só fornece nomes/cidades)
  const quotes = [
    { company: 'Atelier Nord', text: 'O terno sob medida superou tudo o que eu esperava. O caimento é impecável e o tecido, simplesmente nobre.' },
    { company: 'Sartoria Vellure', text: 'Fiz uma consultoria de imagem e saí de lá com um guarda-roupa que finalmente parece meu. Recomendo de olhos fechados.' },
    { company: 'Linho & Co.', text: 'Peças que duram estações. Uso a camisa de linho há dois anos e ela continua parecendo nova.' },
    { company: 'Casa Lumière', text: 'O atendimento do ateliê é um espetáculo à parte. Cada ajuste foi feito com um cuidado que não se vê mais por aí.' },
    { company: 'Tricô Serrano', text: 'Troquei o fast fashion pela moda circular da Veste e nunca mais olhei para trás. Qualidade que se percebe no toque.' }
  ];
  const quote = quotes[index] ?? { company: 'Veste', text: 'Peças atemporais feitas com tecidos nobres e acabamento artesanal.' };

  return `
    <article class="testimonial-card">
      <div class="card-company">
        <span class="company-name">${quote.company}</span>
      </div>

      <p class="card-text">
        "${quote.text}"
      </p>

      <div class="card-author">
        <img
          src="${avatarUrl}"
          alt="Foto de ${user.name}"
          class="author-avatar"
          loading="lazy"
        />

        <div class="author-info">
          <h4 class="author-name">${user.name}</h4>
          <span class="author-role">Cliente / ${city}</span>
        </div>
      </div>
    </article>
  `;
}

function updateActiveCard(cardsContainer) {
  const cards = cardsContainer.querySelectorAll('.testimonial-card');

  if (!cards.length) return;

  const containerCenter = cardsContainer.scrollLeft + cardsContainer.clientWidth / 2;
  let closestCard = null;
  let minDistance = Infinity;

  cards.forEach((card) => {
    const cardCenter = card.offsetLeft + card.offsetWidth / 2;
    const distance = Math.abs(containerCenter - cardCenter);

    if (distance < minDistance) {
      minDistance = distance;
      closestCard = card;
    }
  });

  cards.forEach((card) => card.classList.remove('active'));

  if (closestCard) {
    closestCard.classList.add('active');
  }
}

function initCarouselFocus(cardsContainer) {
  const cards = cardsContainer.querySelectorAll('.testimonial-card');

  if (!cards.length) return;

  if (cards.length >= 3) {
    const targetCard = cards[2];
    const containerWidth = cardsContainer.offsetWidth;
    const cardOffsetLeft = targetCard.offsetLeft;
    const cardWidth = targetCard.offsetWidth;

    cardsContainer.scrollLeft = cardOffsetLeft - containerWidth / 2 + cardWidth / 2;
  }

  updateActiveCard(cardsContainer);
  cardsContainer.onscroll = () => updateActiveCard(cardsContainer);
}